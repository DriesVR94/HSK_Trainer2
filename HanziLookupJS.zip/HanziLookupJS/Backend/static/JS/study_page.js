const isDev = false;
const START_LEVEL = Number(document.body.dataset.level) || 1;

let hanziLoaded = false, assetsLoaded = false;
let hanziList = [];

function loadRandomHanzi() {
  const randomEntry = hanziList[Math.floor(Math.random() * hanziList.length)];

  document.querySelector('.targetCharBox').innerHTML = `
  <strong style="font-size: clamp(14px, 1.8vw, 35px)">
    ${randomEntry.english}
  </strong>
  <span style="font-size: clamp(12px, 1.5vw, 25px); font-style: italic;">
    ${randomEntry.pinyin}
  </span>
`;

  window.targetHanziEntry = randomEntry;
  window.targetCharacter = randomEntry.chinese;

  showExampleCharacter();
  buildBoards();
}

let filesToLoad = 2;
function fileLoaded(ok) {
  if (!ok) { filesToLoad = -1; return; }
  if (--filesToLoad === 0) { assetsLoaded = true; maybeInitBoards(); }
}

function loadLevel(level) {
  hanziLoaded = false;
  document.querySelector('.targetCharBox').innerText = "loading…";

  fetch(`/get_vocabulary?level=${level}`)
    .then(r => r.json())
    .then(data => {
      hanziList = data;
      hanziLoaded = true;
      maybeInitBoards();
    })
    .catch(err => {
      console.error(err);
      document.querySelector('.targetCharBox').innerText = "⚠️ load error";
    });
}

HanziLookup.init('mmah', "/static/dist/mmah.json", fileLoaded);
HanziLookup.init('orig', "/static/dist/orig.json", fileLoaded);

function maybeInitBoards() {
  if (hanziLoaded && assetsLoaded) loadRandomHanzi();
}

function drawGrid(ctx, w, h) {
  ctx.clearRect(0, 0, w, h);
  ctx.strokeStyle = "#ddd";
  ctx.lineWidth = 1;

  const step = w / 4;

  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(step * i, 0);
    ctx.lineTo(step * i, h);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, step * i);
    ctx.lineTo(w, step * i);
    ctx.stroke();
  }
}

function addGridOverlay(boardElem) {
  const canvas = boardElem.querySelector('canvas');
  if (!canvas) return;

  const overlay = document.createElement('canvas');
  overlay.width = canvas.width;
  overlay.height = canvas.height;

  overlay.style.position = 'absolute';
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = canvas.style.width;
  overlay.style.height = canvas.style.height;
  overlay.style.pointerEvents = 'none';
  overlay.style.zIndex = 10;

  boardElem.appendChild(overlay);

  const ctx = overlay.getContext('2d');
  drawGrid(ctx, overlay.width, overlay.height);
}

function showExampleCharacter() {
  const container = document.getElementById('character-target-div');
  container.innerHTML = '';

  const chars = Array.from(window.targetCharacter);

  // Put character boxes next to each other
  container.style.width = 'auto';
  container.style.height = 'auto';
  container.style.display = 'flex';
  container.style.flexDirection = 'row';
  container.style.gap = '10px';
  container.style.justifyContent = 'center';

  chars.forEach(char => {
    const charBox = document.createElement('div');

    charBox.style.width = 'var(--char-box-size)';
    charBox.style.height = 'var(--char-box-size)';
    charBox.style.backgroundColor = '#fafafa';
    charBox.style.border = '3px solid #ee1c25';
    charBox.style.borderRadius = '12px';

    charBox.style.display = 'flex';
    charBox.style.justifyContent = 'center';
    charBox.style.alignItems = 'center';

    container.appendChild(charBox);

    const writer = HanziWriter.create(charBox, char, {
      width: charBox.clientWidth,
      height: charBox.clientHeight,
      padding: 5,
      strokeAnimationSpeed: 1,
      delayBetweenLoops: 3000
    });

    writer.loopCharacterAnimation();
  });
}

function buildBoards() {
  const container = document.getElementById('drawingBoardsContainer');
  container.innerHTML = '';

  const chars = Array.from(window.targetCharacter);
  const practiceBoxesPerCharacter = 6;

  container.style.display = 'flex';
  container.style.flexDirection = 'row';
  container.style.flexWrap = 'wrap';
  container.style.justifyContent = 'center';
  container.style.gap = '20px';
  container.style.width = '100%';
  container.style.maxWidth = '1400px';
  container.style.margin = '0 auto';

  window._drawingBoards = [];

  chars.forEach((char, charIndex) => {

    const charSection = document.createElement('div');
    charSection.className = 'characterPracticeSection';
    charSection.style.width = '100%';
    const probe = document.createElement('div');
    probe.style.width = 'var(--char-box-size)';
    probe.style.position = 'absolute';
    probe.style.visibility = 'hidden';
    document.body.appendChild(probe);

    const boxSize = probe.getBoundingClientRect().width;
    probe.remove();

    const gap = 16;

    const availableWidth = Math.min(
      container.clientWidth,
      1400
    );

    charSection.style.gap = '16px';
    charSection.style.justifyContent = 'center';
    charSection.style.maxWidth = '100%';
    charSection.style.maxWidth = '1400px';
    charSection.style.margin = '0 auto';

    container.appendChild(charSection);


    // Create 6 boxes for this character
    for (let i = 0; i < practiceBoxesPerCharacter; i++) {

      const wrap = document.createElement('div');
      wrap.className = 'boardWrap';

      const inner = document.createElement('div');
      inner.className = 'drawingBoard';

      inner.style.width = 'var(--char-box-size)';
      inner.style.height = 'var(--char-box-size)';
      inner.style.position = 'relative';

      wrap.appendChild(inner);
      charSection.appendChild(wrap);


      const board = HanziLookup.DrawingBoard($(inner), () => {
        lookup(board);
      });

      window._drawingBoards.push(board);


      requestAnimationFrame(() => {
        const canvas = inner.querySelector('canvas');

        if (canvas) {
          const size = inner.clientWidth;

          canvas.width = size;
          canvas.height = size;
          canvas.style.width = `${size}px`;
          canvas.style.height = `${size}px`;
        }

        addGridOverlay(inner);
      });
    }
  });


  if (!isDev) {
    document.querySelectorAll('.dev-only')
      .forEach(el => el.style.display = 'none');
  }
}

document.getElementById('nextButton').onclick = () => loadRandomHanzi();

loadLevel(START_LEVEL);